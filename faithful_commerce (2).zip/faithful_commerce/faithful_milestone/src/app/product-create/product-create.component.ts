import { Component } from '@angular/core';
import { FaithfulCommerceService } from '../faithful-commerce.service';
import { Product } from '../types';
import { FormsModule } from '@angular/forms';


@Component({
  selector: 'app-product-create',
  templateUrl: './product-create.component.html',
  styleUrls: ['./product-create.component.css'],
  standalone: true,
  imports: [FormsModule],
})
export class ProductCreateComponent {
  product: Product = { name: '', description: '' };

  constructor(private productService: FaithfulCommerceService) { }

  createProduct(): void {
    this.productService.createProduct(this.product).subscribe(result => {
      console.log('Product Created', result);
      // Navigate to product list or show success message
    });
  }
}