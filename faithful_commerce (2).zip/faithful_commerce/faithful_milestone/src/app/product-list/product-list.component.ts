import { Component, OnInit } from '@angular/core';
import { FaithfulCommerceService } from '../faithful-commerce.service';
import { Product } from "../types";
@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  standalone: true,
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  products: Product[] = [];

  constructor(private productService: FaithfulCommerceService) { }

  ngOnInit(): void {
    this.productService.getProducts().subscribe(products => {
      this.products = products;
    });
  }
}
