import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FaithfulCommerceService } from '../faithful-commerce.service';

@Component({
  selector: 'app-delete-product',
  standalone: true,
  templateUrl: './product-delete.component.html',
  styleUrls: ['./product-delete.component.css']
})
export class ProductDeleteComponent implements OnInit {
  productId!: number;

  constructor(
    private route: ActivatedRoute,
    private productService: FaithfulCommerceService,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.productId = parseInt(this.route.snapshot.paramMap.get('id')??'', 10);
    if (this.productId) {
      this.productService.deleteProduct(this.productId).subscribe(() => {
        console.log('Product deleted successfully');
        this.router.navigate(['/products']); // Navigate to the products list
      });
    }
  }
}