import { Routes } from '@angular/router';
import { ProductDetailsComponent } from './product-details/product-details.component';
import { ProductCreateComponent } from './product-create/product-create.component';
import { ProductListComponent } from './product-list/product-list.component';
import { ProductEditComponent } from './product-edit/product-edit.component';
import { ProductDeleteComponent } from './product-delete/product-delete.component';

export const routes: Routes = [{path:"product-details", component: ProductDetailsComponent },
                                {path: "product-create", component: ProductCreateComponent },
                                {path: "product-list", component: ProductListComponent},
                                {path: "product-edit", component: ProductEditComponent},
                                {path: "product-delete", component: ProductDeleteComponent}];
