import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { FaithfulCommerceService } from '../faithful-commerce.service';
import { Product } from '../types';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  standalone: true,
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent implements OnInit {
  product: Product | undefined;

  constructor(
    private route: ActivatedRoute,
    private productService: FaithfulCommerceService
  ) { }

  ngOnInit(): void {
    const productId = this.route.snapshot.paramMap.get('id');
    if (productId) {
      this.productService.getProduct(+productId).subscribe(product => {
        this.product = product;
      });
    }
  }
}
