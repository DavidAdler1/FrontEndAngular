import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable, map } from "rxjs";
import { Product } from "./types";
  
  
  @Injectable({
    providedIn: 'root'
  })
  export class FaithfulCommerceService {
    private apiUrl = 'http://localhost:3000/api/products';
  
    constructor(private http: HttpClient) { }
  
    // List Products
    getProducts(): Observable<Product[]> {
      return this.http.get<Product[]>(this.apiUrl);
    }
  
    // Read Product
    getProduct(id: number): Observable<Product> {
      return this.http.get<Product>(`${this.apiUrl}/${id}`);
    }
  
    // Create Product
    createProduct(product: Product): Observable<Product> {
      return this.http.post<Product>(this.apiUrl, product);
    }
  
    // Update Product
    updateProduct(id: number, product: Product): Observable<Product> {
      return this.http.put<Product>(`${this.apiUrl}/${id}`, product);
    }
  
    // Delete Product
    deleteProduct(id: number): Observable<{ message: string }> {
      return this.http.delete<{ message: string }>(`${this.apiUrl}/${id}`);
    }
  }