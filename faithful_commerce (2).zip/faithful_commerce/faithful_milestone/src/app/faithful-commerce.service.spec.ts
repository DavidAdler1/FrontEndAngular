import { TestBed } from '@angular/core/testing';

import { FaithfulCommerceService } from './faithful-commerce.service';

describe('FaithfulCommerceService', () => {
  let service: FaithfulCommerceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FaithfulCommerceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
