import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FaithfulCommerceService} from '../faithful-commerce.service';
import { Product } from '../types';
import { FormsModule } from '@angular/forms';


@Component({
  selector: 'app-edit-product',
  standalone: true,
  templateUrl: './product-edit.component.html',
  styleUrls: ['./product-edit.component.css'],
  imports: [FormsModule],
})
export class ProductEditComponent implements OnInit {
  product: Product = { id: 0, name: '', description: '' };

  constructor(
    private route: ActivatedRoute,
    private productService: FaithfulCommerceService,
    private router: Router
  ) { }

  ngOnInit(): void {
    const productId = parseInt(this.route.snapshot.paramMap.get('id')??'', 10);
    if (productId) {
      this.productService.getProduct(productId).subscribe(product => {
        this.product = product;
      });
    }
  }

  updateProduct(): void {
    this.productService.updateProduct(this.product.id!, this.product).subscribe(() => {
      console.log('Product updated successfully');
      this.router.navigate(['/products']); // Navigate to the products list
    });
  }
}